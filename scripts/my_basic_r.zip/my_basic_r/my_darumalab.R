#' ---
#' title: "[ベイカー・ストリート](https://darumalab.github.io/)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.time()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # [Rプログラミングの学習](https://darumalab.github.io/bootcamp/2017-07-16-tutorials/)
#' 
#' - [Rプログラミングと統計: コードのサンプル](https://github.com/darumalab/Intro_R)
#' - [Rプログラミングと統計 - YouTube](https://www.youtube.com/watch?v=jjkBsU4AChM&list=PLdNQOrt5fdN8P-vy1i6vep9OP4R1AZcEb)
#' 
#' Cmd/Ctrl + Enter 
#' 
#' ## [Part 3: R言語 オブジェクト - R Objects](https://darumalab.github.io/bootcamp/2017-07-13-objects/)

2 + 2
.Last.value

## オブジェクトの作成
x <- 2 + 2
x
y <- 5 * 5
y
myname <- "Joe"
myname

## 作成したオブジェクト名を確認
objects()
ls()

## ワーキングディレクトリ
getwd() #確認
#setwd("") #変更

## オブジェクトの保存
save(x, y, myname, file = "MyObjects.RData") #x,y,mynameを保存

## オブジェクトの読み込み
load("MyObjects.RData")

## オブジェクトの削除
rm(x) #xを削除
rm(x, y) #x,y,mynameを削除
rm(list = objects()) #全て削除

#' ## [Part 4: R言語 データのタイプ - R Data Types](https://darumalab.github.io/bootcamp/2017-07-17-type/)

## 数値データ
num <- 7

## オブジェクトが数値データなのかチェック
is.numeric(num)
class(num)

## オブジェクトが整数なのかチェック
is.integer(num)
num2 <- 7L
is.integer(num2)

## 文字列データ
char <- "テキスト"
char2 <- factor("テキスト") #文字列をファクターとして保存

## オブジェクトが文字列データなのかチェック
is.character(char)
class(char)

## 日付データ
#date <- as.Date("YYYY-MM-DD") #例:2017-04-15
date <- as.Date("2017-04-15")
date

## オブジェクトが日付データなのかチェック
class(date)

#date2 <- as.POSIXct("YYYY-MM-DD 00:00")
date2 <- as.POSIXct("2017-04-15 18:00")
date2

## 論理データ
logi <- TRUE
logi2 <- FALSE
logi3 <- NA

## オブジェクトが論理データなのかチェック
is.logical(logi)
class(logi)

#' ## [Part 5: R言語 ベクトルの扱い方 - R Vectors](https://darumalab.github.io/bootcamp/2017-07-17-vectors/)
#' 
#' [ベクトルに関する Tips 大全](http://www.okadajp.org/RWiki/?ベクトルTips大全)

## ベクトルの作成
a <- c(1, 2, 3, 4, 5)
a
b <- c("dog", "cat", "bee")
b
c <- c(TRUE, FALSE, TRUE)
c

x <- 1:5
x
y <- 5:1
y
z <- -5:5
z

# 和訳
# seq() - sequence: 数列
# rep() - replicate: 複製する

?seq() #関数のヘルプドキュメントを開く
seq(from = 1, to = 5, by = 1)
seq(from = 1, to = 5, by = 0.5)
seq(from = 1, to = 5, by = 1 / 2)

rep(1, times = 5)
rep(c(1, 3, 5), times = 5)
rep("dog", times = 5)
rep(c("dog", "cat"), times = 5)
rep(TRUE, times = 5)
rep(c(FALSE, TRUE), times = 5)

## ベクトルの要素の数を調べる
length(x)
length(rep(1, times = 3))

## ベクトルの要素にアクセスする
y[2]
y[c(1, 3)]  #c()で複数の要素にアクセス
y[-c(1, 3)] #-c()で複数の要素を取り除く
y[y < 4]

## 演算 pt1
z + 2
z - 2
z * 2
z / 2
z ^ 2
sqrt(z) #平方根

x1 <- c(1, 3, 5)
y1 <- c(2, 4, 6)
x1 + y1
x1 - y1
x1 * y1
x1 / y1

## 演算 pt2
# 要素の数（長さ）の違うベクトルでは、
# 長いベクトルに合わせて短いベクトルが再利用される
x2 <- c(1, 3, 5)
z2 <- c(1, 2, 3, 4, 5, 6)
z2 + x2
z2 - x2

#' ## [Part 6: R言語 NA 欠損値 - R Missing Data](https://darumalab.github.io/bootcamp/2017-07-17-na/)

x <- NA

## ベクトル
num <- c(1,2,NA,4)
str <- c("dog", NA, "cat", "bee")
logi <- c(TRUE, NA, FALSE, TRUE)

## データのタイプ
mode(num)
mode(str)
mode(logi)

## NA(欠損値)の検出
is.na(num) 
!is.na(num)
is.na(str)
!is.na(str)
is.na(logi)

## NAのインデックス:
which(is.na(num))  #which()でTRUEのインデックスを検出
which(is.na(str))
which(is.na(logi))

mean(num)
?mean
mean(num, na.rm=TRUE)

## ベクトルからNAを取り除く
num <- num[!is.na(num)]
mean(num)

#' ## [Part 7: R言語 行列 - R Matrices](https://darumalab.github.io/bootcamp/2017-07-17-matrices/)
#' 
#' ## [Part 8: R言語 データフレーム - R Data Frame](https://darumalab.github.io/bootcamp/2017-07-17-dataframe/)
#' 
#' ## [Part 9: R言語 リスト - R Lists](https://darumalab.github.io/bootcamp/2017-07-17-lists/)
#' 
#' ## [Part 10: R言語 データの読み込み - R Importing Data](https://darumalab.github.io/bootcamp/2017-07-14-import/)
#' 
#' ## []()
#' 



