#' ---
#' title: "[ベイカー・ストリート](https://darumalab.github.io/)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.time()`"
#' output:
#'    html_document:
#'      toc: true
#' ---
#' 
#' # [Rプログラミングの学習](https://darumalab.github.io/bootcamp/2017-07-16-tutorials/)
#' 
#' - [Rプログラミングと統計: コードのサンプル](https://github.com/darumalab/Intro_R)
#' - [Rプログラミングと統計 - YouTube](https://www.youtube.com/watch?v=jjkBsU4AChM&list=PLdNQOrt5fdN8P-vy1i6vep9OP4R1AZcEb)
#' 
#' Cmd/Ctrl + Enter 
#' 
#' ## [R言語 オブジェクト - R Objects](https://darumalab.github.io/bootcamp/2017-07-13-objects/)
#' 
2 + 2
.Last.value

## オブジェクトの作成
x <- 2 + 2
x
y <- 5 * 5
y
myname <- "Joe"
myname

## 作成したオブジェクト名を確認
objects()
ls()

## ワーキングディレクトリ
getwd() #確認
#setwd("") #変更

## オブジェクトの保存
save(x, y, myname, file = "ファイル名.RData") #x,y,mynameを保存

## オブジェクトの読み込み
load("ファイル名.RData")

## オブジェクトの削除
rm(x) #xを削除
rm(x, y) #x,y,mynameを削除
rm(list = objects()) #全て削除

#' ## [R言語 データのタイプ- R Data Types](https://darumalab.github.io/bootcamp/2017-07-17-type/)
#' 

#' ## [R言語 ベクトル - R Vectors](https://darumalab.github.io/bootcamp/2017-07-17-vectors/)
#' 

#' ## 
#' 



