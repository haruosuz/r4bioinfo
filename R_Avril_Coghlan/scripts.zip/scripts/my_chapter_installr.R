#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.time()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' ## [R言語入門](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#how-to-install-r-and-a-brief-introduction-to-r)
#' ## [How to install R and a Brief Introduction to R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html)
#' ### Introduction to R
#' 
#' - [R言語入門 (全13回) - プログラミングならドットインストール](http://dotinstall.com/lessons/basic_r)
#' - [R-Tips](http://cse.naro.affrc.go.jp/takezawa/r-tips/r.html)
#' - [R | R の使い方、グラフの書き方、ggplot の使い方](https://stats.biopapyrus.jp/r/)
#' 
#' ### [Installing R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r)
#' 
#' - [R のインストール - RjpWiki](http://www.okadajp.org/RWiki/?R%20のインストール)
#' - [01.セットアップ・参考文献](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/01.html)
#' 
#' ### [Installing R packages](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#installing-r-packages)
#' 
#' - [R言語 CRANパッケージ一覧 | トライフィールズ](https://www.trifields.jp/statistical-analysis-r-cran-packages-341)
#' - [08. パッケージ・ライブラリ](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/08.html)
#' - [パッケージ | R のパッケージのインストール方法と呼び出し方](https://stats.biopapyrus.jp/r/basic/package.html)
#' - [Bioconductor: Genomicデータ解析ツール群 - Heavy Watal](https://heavywatal.github.io/rstats/bioconductor.html)
#' 
#' #### [How to install an R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-an-r-package)
#' パッケージ[`seqinr`](https://cran.r-project.org/package=seqinr)のインストール:  
# install the "seqinr" package
#install.packages("seqinr")

#' `seqinr`パッケージの呼び出し:  
# load the "seqinr" package into R
library(seqinr)

#' #### [How to install a Bioconductor R package](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#how-to-install-a-bioconductor-r-package)
#' Bioconductorパッケージ[`Biostrings`](http://bioconductor.org/packages/release/bioc/html/Biostrings.html)のインストール:  
# install the Bioconductor package called "Biostrings"
#install.packages("BiocManager")
#BiocManager::install("Biostrings")

#' `Biostrings`パッケージの呼び出し:  

# load the "Biostrings" package into R
suppressMessages(library(Biostrings))

#' ### [Running R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#running-r)
#' 
#' - [02. R の起動と終了](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/02.html)  
#' 
#' ![](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/image/windows.gif)
#' ![http://cse.naro.affrc.go.jp/takezawa/r-tips/r/02.html](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/image/Mac.gif)
#' 
#' Rを終了:  
# To quit R, type:
#quit()
#q()

#' ### [A brief introduction to R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#a-brief-introduction-to-r)
#' 
#' [簡単な計算](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/03.html)  
#' 演算子
# typing in commands
2*3
10-3

#' [オブジェクトと代入（付値）](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/05.html)
# assign the value 2*3 to the variable x
x <- 2*3

# To view the contents of any R object, just type its name
x

#' データ型：文字列(character)、複素数(complex)、実数(numeric)、論理値(logical)など  
#' [09. データの型](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/09.html)  
#' [25. データ型とデータ構造](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/25.html) character > complex > numeric > logical > NULL  
#' [データ型 | R のデータ型・モード・クラス](https://stats.biopapyrus.jp/r/basic/data-type.html)  
#' [R:データ型](http://www.f.waseda.jp/sakas/R/Rdata.html) データ型の自動変換 logical < integer < double < complex < character 
#' 
#' [ベクトル | R のベクトル操作と演算](https://stats.biopapyrus.jp/r/basic/vector.html)  
#' ベクトルの作成は関数`c()`を用いる。
# create a vector called myvector that has elements with values 8, 6, 9, 10, and 5:
myvector <- c(8, 6, 9, 10, 5)

# see the contents of the variable myvector:
myvector

#' [13. ベクトル要素へのアクセス](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/13.html)  
#' インデックス（添字）  
# get the value of the 4th element in the vector myvector
myvector[4]

#' [23. リスト](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/23.html)  
#' リストは異なる型（数値や文字列）のデータをまとめられる。
#' リストの作成は関数`list()`を用いる。
# In contrast to a vector, a list can contain elements of different types (e.g. both numeric and character elements).
# create a list mylist:
mylist <- list(name="Fred", wife="Mary", myvector)
mylist

#' `[[ ]]`はリスト内の要素（ベクトル）を取り出す。
# extract the second and third elements from mylist:
mylist[[2]]
mylist[[3]]

#' リストの要素に名前が付けられている場合、`$`記号でアクセスする。
# mylist$wife is the same as mylist[[2]]:
mylist$wife

# find the names of the named elements in a list
attributes(mylist)

#' [table 関数を使ったクロス集計](http://nshi.jp/contents/r/crosstab/)

# produce a table variable that contains the number of bases:
mybases <- c("A", "C", "G", "T", "A")
table(mybases)
# store the table variable produced by the function table(), and call the stored table “mytable”:
mytable <- table(mybases)
mytable
# access the 1st element in the table mytable (the number of base “A”):
mytable[[1]]
mytable[["A"]]

#' [簡単な計算](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/03.html)  
#' 関数

# calculate the log to the base 10 of a number:
log10(100)

#' [ヘルプ](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/07.html)

# get help about a particular function
help(log10)

#' 標準偏差 standard deviation を計算する関数を探す

# search for all functions containing the word “deviation” in their description:
#help.search("deviation")
#RSiteSearch("deviation")

#' ベクトルの値の平均

# calculate the average of the values in the vector myvector
mean(myvector)

#' [31. 関数の定義](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/31.html)  

# create a function to calculate the value of 20 plus square of some input number:
myfunction <- function(x) { return(20 + (x*x)) }
# use the function for different input numbers (eg. 10, 25):
myfunction(10)
myfunction(25)

#' ### [Links and Further Reading](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/installr.html#links-and-further-reading)
#' 
sessionInfo()
