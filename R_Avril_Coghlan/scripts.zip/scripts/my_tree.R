rm(list = ls())

# Loading packages
#+ warning = FALSE
#+ message = FALSE
library(seqinr)
library(ape)
library(phangorn)

library(Biostrings)
library(DECIPHER)

library(tidyverse)
require(ggseqlogo)

#' # NCBI Protein
#' 
#' - http://togows.dbcls.jp/site/ja/rest.html
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3294859/figure/F1/ Yano_2012 Fig 1 TrfA
#' - https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8034659/figure/F1/ Wegrzyn_2021 Figure 1. TrfA WH domains 
togows_protein_fasta <- function(ACCESSION) seqinr::read.fasta(file = paste0("http://togows.dbcls.jp/entry/protein/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#ACCESSIONs <- c() # Make a vector containing ACCESSION (protein_id) of the sequences
ACCESSIONs <- c("CAJ85684", "BAF33454", "CAJ43307", "ADD63272") # TrfA (RK2, pBP136, QKH54, pAKD4)
ACCESSIONs <- c("CAJ85684", "BAF33454", "CAJ43307", "ADD63272", "CAA41700") # TrfA (RK2, pBP136, QKH54, pAKD4), RepA (pPS10)
#seqs <- lapply(ACCESSIONs, togows_protein_fasta) # Retrieve the sequences and store them in list variable "seqs"
file.fasta <- "data/myNCBIprotein.fasta"

#' # UniProt
#' 
#' - https://www.uniprot.org/help/fasta-headers
#' - HASEGAWA et al. 1990 "Close evolutionary relatedness of archaebacteria, Methanococcus and Halobacterium, to eukaryotes demonstrated by composite phylogenetic trees of elongation factors EF-Tu and EF-G: Eocyte tree is unlikely" https://www.jstage.jst.go.jp/article/jjg/65/3/65_3_109/_article/-char/ja/
#' - Iwabe et al. 1989 "Evolutionary relationship of archaebacteria, eubacteria, and eukaryotes inferred from phylogenetic trees of duplicated genes." https://www.ncbi.nlm.nih.gov/pmc/articles/PMC298494/
retrieve_seqs_uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
ACCESSIONs <- c("Q8U152","P61877","Q9SI75","P25039","P80868","P0A6M8","P0CE47","P0CE48","P17745","P33166","P02992"); outgroups <- c("P61877","Q9SI75","P25039","P80868","P0A6M8") # EF
#seqs <- lapply(ACCESSIONs,  retrieve_seqs_uniprot)
file.fasta <- "data/myUniProt.fasta"

#' Write sequence(s) into a file in fasta format
#write.fasta(sequences=seqs, names=getAnnot(seqs), file.out=file.fasta, nbchar=max(getLength(seqs)))

#' Read amino-acid sequences from a file in FASTA format.
file.fasta <- "data/myNCBIprotein.fasta" # NCBI Protein
file.fasta <- "data/myUniProt.fasta" # UniProt
seqs <- read.fasta(file=file.fasta, seqtype="AA", strip.desc=TRUE)

#' creates data frame (table)
Length <- getLength(seqs) # get the length of sequences
Annotation <- unlist(getAnnot(seqs)) # get sequence annotations
# NCBI Protein
Accession <- gsub(pattern="^([^ ]+) .+", replacement="\\1", x=Annotation)
ProteinName <- gsub(pattern="^([^ ]+)\\.[0-9]+ (.+) \\[(.+)\\]", replacement="\\2", x=Annotation)
OrganismName <- gsub(pattern=".+\\[(.+)\\]", replacement="\\1", x=Annotation)
# UniProt
#Accession <- gsub(pattern="^sp\\|([^ ]+)\\|.+", replacement="\\1", x=Annotation)
#ProteinName <- gsub(pattern="^([^ ]+) (.+) OS=.+", replacement="\\2", x=Annotation)
#OrganismName <- gsub(pattern=".+ OS=(.+) OX=.+", replacement="\\1", x=Annotation)
#
d.f <- data.frame(Length, Annotation, Accession, ProteinName, OrganismName) %>% arrange(desc(`Length`))
write_csv(x=d.f, file="analysis/table.csv")
knitr::kable(x = d.f, caption = "Table 1. Sequence data.")

#' Histograms
#par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(3,3,3,3), cex=1) # c(bottom, left, top, right)
hist(d.f$Length)
#' - https://r4ds.had.co.nz/exploratory-data-analysis.html
ggplot(d.f, aes(x = `Length`)) + geom_histogram(bins = 5)

#' # DECIPHER: multiple sequence alignment
#' 
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_DECIPHER
#' - https://bioconductor.org/packages/release/bioc/vignettes/DECIPHER/inst/doc/ArtOfAlignmentInR.pdf
#library(DECIPHER)
myAAStringSet <- Biostrings::readAAStringSet(filepath=file.fasta)
myAlignAA <- AlignSeqs(myAAStringSet)
#DECIPHER::BrowseSeqs(myAlignAA, threshold = 0.5) # ?ConsensusSequence

myAlignAA
#as.character(myAlignAA)

#' # ggseqlogo: Sequence Logos
#' 
#' - https://cran.r-project.org/package=ggseqlogo
#' - Vignettes https://omarwagih.github.io/ggseqlogo/
#install.packages("ggseqlogo")
#require(ggplot2)
#require(ggseqlogo)
#?geom_logo
ggseqlogo(as.character(myAlignAA), seq_type='aa', method='prob')
ggseqlogo(substr(as.character(myAlignAA),200,230), seq_type='aa', method='bits')

#' # Phylogenetic Trees Made Easy : A How-to Manual
#' ## Check Average Identity to Estimate Reliability of the Alignment
#' ### Codons: Pairwise amino acid identity
#' The p-distance is 1–amino acid identity; thus 
#' if the average p-distance is <0.7 the alignment is acceptable; 
#' if ≥0.7 it is unreliable.
file.align <- "analysis/myAlignAA.fasta"
writeXStringSet(myAlignAA, filepath=file.align)
myaln <- seqinr::read.alignment(file=file.align, format="fasta")
mydist <- seqinr::dist.alignment(x=myaln, matrix="identity")
mean(mydist ^ 2)

mytree <- ape::nj(mydist)
#mytree <- ape::root(phy=mytree, outgroup=outgroups, resolve.root=TRUE)
mytree <- phangorn::midpoint(mytree)
mytree <- ape::ladderize(mytree, right = FALSE)
ape::plot.phylo(mytree, type="phylogram", main="rooted tree")
file.tree <- "analysis/my_ape_nj.tre"
write.tree(mytree, file=file.tree)
mytree <- read.tree(file=file.tree)
#x <- mytree$tip.label[1]; TF <- grepl(pattern=x, x=d.f[,"Accession"]); summary(TF); d.f[TF,]; paste(d.f[TF,c("Accession","OrganismName")],collapse="~")
#mytree$tip.label <- sapply(mytree$tip.label, function(x) paste(d.f[grepl(pattern=x, x=d.f[,"Accession"]),c("Accession","OrganismName")],collapse="~") )
mytree$tip.label <- sapply(mytree$tip.label, function(x) paste(d.f[grepl(pattern=x, x=d.f[,"Accession"]),c("Accession","ProteinName","OrganismName")],collapse="~") )
par(mfrow=c(1,1), mgp=c(1.7, 0.5, 0), mar=c(1, 0.5, 0.5, 0.5), cex=0.7) # c(bottom, left, top, right)
ape::plot.phylo(mytree, type="phylogram", show.node.label=TRUE, font=3)
add.scale.bar(x=0.01, y=0.9)#, col=2)
title(basename(file.tree))

#' # phangorn
#' 
#' - https://github.com/haruosuz/r4bioinfo/tree/master/R_phangorn
#' - Vignettes: https://cran.r-project.org/web/packages/phangorn/vignettes/Trees.html
#library(phangorn)
myphyDat <- read.phyDat(file=file.align, format="fasta", type="AA")
myfun <- function(x) upgma(dist.ml(x, model="JTT"))
mytree <- myfun(myphyDat)
set.seed(123)
BStrees <- bootstrap.phyDat(myphyDat, FUN=myfun, bs=100)
treeBS <- plotBS(mytree, BStrees, "phylogram")

#getwd()
#list.files()
sessionInfo()
Sys.time()

