#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

#' ## [多重配列アライメントと系統樹](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#multiple-alignment-and-phylogenetic-trees)
#' ## [Multiple Alignment and Phylogenetic trees](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html)
#' **多重配列アラインメントと系統樹**
#' 
#' - [多重整列](https://ja.wikipedia.org/wiki/多重整列) [マルチプルアライメント](http://bio-info.biz/article/ase_msa.html) [Multiple sequence alignment](https://en.wikipedia.org/wiki/Multiple_sequence_alignment) 
#' - [系統樹](https://ja.wikipedia.org/wiki/系統樹) [Phylogenetic tree](https://en.wikipedia.org/wiki/Phylogenetic_tree) 
#' - [系統学](https://ja.wikipedia.org/wiki/系統学) [Phylogenetics](https://en.wikipedia.org/wiki/Phylogenetics)
#' - [分子系統学](https://ja.wikipedia.org/wiki/分子系統学) [Molecular phylogenetics](https://en.wikipedia.org/wiki/Molecular_phylogenetics)
#' - 2018-07-30 [How to read a phylogenetic tree](https://artic.network/how-to-read-a-tree.html) | Author: Andrew Rambaut
#' - Sep 4, 2017 https://www.youtube.com/watch?v=t0iAm-JQcrs Parsimony 6:25
#' 
#' ![https://bioinf.comav.upv.es/courses/biotech3/theory/phylogeny.html](https://bioinf.comav.upv.es/courses/biotech3/static/phylogeny/phylo_msa.png)
#' 
#' [`msa`](https://bioconductor.org/packages/release/bioc/html/msa.html)パッケージのインストール:  

# Install the "msa" package:
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

#BiocManager::install("msa")

#' [`ape`](http://ape-package.ird.fr/ape_installation.html)パッケージのインストール:  

# Install the "ape" package:
#install.packages("ape")

#' - [SeaView - Multiplatform GUI for molecular phylogeny](http://doua.prabi.fr/software/seaview)
#' 
#' ### [Retrieving a list of sequences from UniProt](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#retrieving-a-list-of-sequences-from-uniprot)
#' **UniProtから複数の配列を取得**
#' 
#' [狂犬病ウイルス](https://ja.wikipedia.org/wiki/狂犬病ウイルス) Rabies virus, Mokola virus, Lagos bat virus, West Caucasian bat virus の Phosphoprotein のタンパク質配列（UniProt accession: 
#' [P06747](http://www.uniprot.org/uniprot/P06747), [P0C569](http://www.uniprot.org/uniprot/P0C569), [O56773](http://www.uniprot.org/uniprot/O56773), [Q5VKP1](http://www.uniprot.org/uniprot/Q5VKP1)）を取得し、FASTA形式で保存する:  
#' 
#' to retrieve the protein sequences for UniProt accessions P06747, P0C569, O56773 and Q5VKP1 (the accessions for rabies virus phosphoprotein, Mokola virus phosphoprotein, Lagos bat virus phosphoprotein and Western Caucasian bat virus phosphoprotein, respectively):

library("seqinr")
# create a function to retrieve several sequences from UniProt
retrieve_seqs_uniprot <- function(ACCESSION) read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]

seqnames <- c("P06747", "P0C569", "O56773", "Q5VKP1") # Make a vector containing the names of the sequences
seqs <- lapply(seqnames,  retrieve_seqs_uniprot) # Retrieve the sequences and store them in list variable "seqs"
length(seqs)      # Print out the number of sequences retrieved
seq1 <- seqs[[1]] # Get the 1st sequence
seq1[1:20]        # Print out the first 20 letters of the 1st sequence
seq2 <- seqs[[2]] # Get the 2nd sequence
seq2[1:20]        # Print out the first 20 letters of the 2nd sequence

# write the sequences to a FASTA-format file
write.fasta(seqs, seqnames, file="phosphoproteins.fasta")

#' ### [Installing the CLUSTAL multiple alignment software](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#installing-the-clustal-multiple-alignment-software)
#' 
#' 多重整列プログラム [Clustal](https://ja.wikipedia.org/wiki/Clustal)
#' 
#' ### [Creating a multiple alignment of protein, DNA or mRNA sequences using CLUSTAL](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#creating-a-multiple-alignment-of-protein-dna-or-mrna-sequences-using-clustal)
#' **CLUSTALを用いたタンパク質/DNA/mRNA配列の多重アラインメントの作成**

#+ message = FALSE
# Read an XStringSet object from a file
library(Biostrings)
mySequences <- readAAStringSet(file = "phosphoproteins.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
#?msa::msa
myAlignment <- msa(inputSeqs=mySequences, method="ClustalW")
myAlignment

# write an XStringSet object to a file
writeXStringSet(unmasked(myAlignment), file = "myaln.fasta")

#getwd()
#list.files()

#' ### [Reading a multiple alignment file into R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#reading-a-multiple-alignment-file-into-r)
#' **多重アラインメントのファイルをRに読み込む**

library(seqinr)
myaln <- read.alignment(file = "myaln.fasta", format = "fasta")
names(myaln)
myaln$seq

#' ### [Viewing a long multiple alignment](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#viewing-a-long-multiple-alignment)
#' **多重アラインメントの表示**

print(myAlignment, show="complete")

#' ### [Discarding very poorly conserved regions from an alignment](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#discarding-very-poorly-conserved-regions-from-an-alignment)
#' **アラインメントから保存度の低い領域を破棄する**
#' 
#' Trimming a multiple sequence alignment by discarding columns with too many gaps.
#' 
#' 多重配列アラインメントからギャップの多い列を破棄する

#+ message = FALSE
# install.packages("microseq")
library(microseq)
msa <- readFasta(in.file = "myaln.fasta")
print(nchar(msa$Sequence))
msa.trimmed <- msaTrim(msa = msa, gap.end = 0.5, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "msa.trimmed.fasta", width = 80)
# myaln <- read.alignment(file = "msa.trimmed.fasta", format = "fasta")

#' ### [Calculating genetic distances between protein sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-protein-sequences)
#' **タンパク質配列間の遺伝的距離を計算する**
#' 
#' A common first step in performing a phylogenetic analysis is to calculate the pairwise genetic distances between sequences. The genetic distance is an estimate of the divergence between two sequences, and is usually measured in quantity of evolutionary change (an estimate of the number of mutations that have occurred since the two sequences shared a common ancestor).

mydist <- dist.alignment(myaln) # Calculate the genetic distances
mydist                          # Print out the genetic distance matrix

#' 距離行列より、"O56773"と"P0C569"との間の遺伝的距離が最小（0.4142670）、"Q5VKP1"と"O56773"との間の遺伝的距離が最大（0.5067117）である。
#' 
#' Based on the genetic distance matrix above, we can see that the genetic distance between Lagos bat virus phosphoprotein (O56773) and Mokola virus phosphoprotein (P0C569) is smallest (about 0.414).
#' 
#' Similarly, the genetic distance between Western Caucasian bat virus phosphoprotein (Q5VKP1) and Lagos bat virus phosphoprotein (O56773) is the biggest (about 0.507).
#' 
#' The larger the genetic distance between two sequences, the more amino acid changes or indels that have occurred since they shared a common ancestor, and the longer ago their common ancestor probably lived.
#' 
#' ### [Building an unrooted phylogenetic tree for protein sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-an-unrooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の無根系統樹の構築**
#' 
#' Once we have a distance matrix that gives the pairwise distances between all our protein sequences, we can build a phylogenetic tree based on that distance matrix. One method for using this is the neighbour-joining algorithm.
#' 
#' タンパク質配列の距離行列に基づいて、[近隣結合法 NJ (Neighbor-Joining)](https://ja.wikipedia.org/wiki/近隣結合法) により系統樹を構築する。系統樹では、"Q5VKP1"と"P06747"が群を形成し、"O56773"と"P0C569"が群を形成した。

#+ message = FALSE
# construct a phylogenetic tree with the neighbor joining algorithm
library(ape)
mytree <- nj(mydist)
plot.phylo(mytree, type="unrooted") # plot the unrooted phylogenetic tree

# get sequence annotations
unlist(getAnnot(seqs))

#' 
#' We can see that Q5VKP1 (Western Caucasian bat virus phosphoprotein) and P06747 (rabies virus phosphoprotein) have been grouped together in the tree, and that O56773 (Lagos bat virus phosphoprotein) and P0C569 (Mokola virus phosphoprotein) are grouped together in the tree.
#' 
#' This is consistent with what we saw above in the genetic distance matrix, which showed that the genetic distance between Lagos bat virus phosphoprotein (O56773) and Mokola virus phosphoprotein (P0C569) is relatively small.
#' 
#' The lengths of the branches in the plot of the tree are proportional to the amount of evolutionary change (estimated number of mutations) along the branches.
#' 
#' The tree above of the virus phosphoproteins is an unrooted phylogenetic tree as it does not contain an outgroup sequence, that is a sequence of a protein that is known to be more distantly related to the other proteins in the tree than they are to each other.
#' 
#' As a result, we cannot tell which direction evolutionary time ran in along the internal branches of the tree.
#' 
#' ### [Building a rooted phylogenetic tree for protein sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-rooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の有根系統樹の構築**
#' 
#' フラビウイルス属に属するジカウイルス (Zika virus) とデングウイルス (Dengue virus) の非構造タンパク質 (Nonstructural protein 1; NS1) の相同タンパク質配列を取得し、多重配列アラインメントに基づく有根系統樹を構築する。外群としてジカウイルスを選択し、系統樹に根をつける。
#' 
#' In order to convert the unrooted tree into a rooted tree, we need to add an outgroup sequence. Normally, the outgroup sequence is a sequence that we know from some prior knowledge to be more distantly related to the other sequences under study than they are to each other.
#' 
#' 1. Calculate the genetic distances between the following NS1 proteins from different Dengue virus strains: Dengue virus 1 NS1 protein (Uniprot Q9YRR4), Dengue virus 2 NS1 protein (UniProt Q9YP96), Dengue virus 3 NS1 protein (UniProt B0LSS3), and Dengue virus 4 NS1 protein (UniProt Q6TFL5). 
#' 2. Build an unrooted phylogenetic tree of the NS1 proteins from Dengue virus 1, Dengue virus 2, Dengue virus 3 and Dengue virus 4, using the neighbour-joining algorithm.
#' 3. The Zika virus is related to Dengue viruses, but is not a Dengue virus, and so therefore can be used as an outgroup in phylogenetic trees of Dengue virus sequences. UniProt accession Q32ZE1 consists of a sequence with similarity to the Dengue NS1 protein, so seems to be a related protein from Zika virus.

seqnames <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5", "Q32ZE1") # Make a vector containing the names of the sequences
# retrieve several sequences from UniProt
library("seqinr")
retrieve_seqs_uniprot <- function(ACCESSION) read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
seqs <- lapply(seqnames,  retrieve_seqs_uniprot) # Retrieve the sequences and store them in list variable "seqs"

# write out the sequences to a FASTA file
write.fasta(seqs, seqnames, file="myseq.fasta")

# Read an XStringSet object from a file
library(Biostrings)
mySequences <- readAAStringSet(file = "myseq.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
myAlignment <- msa(mySequences, "ClustalW")

# write an XStringSet object to a file
writeXStringSet(unmasked(myAlignment), file = "myaln.fasta")

# read the FASTA-format alignment into R
myaln <- read.alignment(file = "myaln.fasta", format = "fasta")

# calculate the genetic distances between the protein sequences
mydist <- dist.alignment(myaln)
mydist

# construct a phylogenetic tree with the neighbor joining algorithm
library(ape)
mytree <- nj(mydist)
mytree <- root(mytree, outgroup = "Q32ZE1", resolve.root = TRUE)
plot.phylo(mytree, main = "Phylogenetic Tree")

# get sequence annotations
unlist(getAnnot(seqs))

#' ### [Saving a phylogenetic tree as a Newick-format tree file](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#saving-a-phylogenetic-tree-as-a-newick-format-tree-file)
#' **系統樹をNewick形式ファイルとして保存する**
  
write.tree(mytree, file="mytree.newick")

#' ### [Calculating genetic distances between DNA/mRNA sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-dna-mrna-sequences)
#' **DNA/mRNA配列間の遺伝的距離を計算する**

library("seqinr")
# create a function to retrieve several nucleotide sequences from NCBI
retrieve_ncbi_fna <- function(ACCESSION) read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]

seqnames <- c("AF049118", "AF049114", "AF049119", "AF049115")  # Make a vector containing the names of the sequences
seqs <- lapply(seqnames, retrieve_ncbi_fna) # Retrieve the sequences and store them in list variable "seqs"

# get sequence annotations
unlist(getAnnot(seqs))

# write out the sequences to a FASTA-format file
write.fasta(seqs, seqnames, file="virusmRNA.fasta")

# Read an XStringSet object from a file
library(Biostrings)
mySequences <- readDNAStringSet(file = "virusmRNA.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
myAlignment <- msa(mySequences)
myAlignment
#print(myAlignment, show="complete")

# convert msa for the seqinr package
virusmRNAaln <- msaConvert(myAlignment, type="seqinr::alignment")

# calculate a genetic distance for DNA/mRNA sequences
library(ape)
virusmRNAalnbin <- as.DNAbin(virusmRNAaln)              # Convert the alignment to "DNAbin" format
virusmRNAdist <- dist.dna(virusmRNAalnbin, model="K80") # Calculate the genetic distance matrix
virusmRNAdist                                           # Print out the genetic distance matrix

#' ### [Building a phylogenetic tree for DNA or mRNA sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-phylogenetic-tree-for-dna-or-mrna-sequences)
#' **DNA/mRNA配列の系統樹の構築**

# construct a phylogenetic tree with the neighbor joining algorithm
library(ape)
mytree <- nj(virusmRNAdist)
plot.phylo(mytree, type="unrooted") # plot the unrooted phylogenetic tree

#' ### Summary

# library(seqinr)
?read.alignment
?dist.alignment

# library(msa)
#example(msa)

# library(ape)
?dist.dna
#example(nj)
?write.tree

#' ### [Links and Further Reading](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#links-and-further-reading)
