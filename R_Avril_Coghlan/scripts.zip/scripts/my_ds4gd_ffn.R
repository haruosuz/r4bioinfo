#' - https://github.com/haruosuz/DS4GD/blob/master/2019giga/CaseStudy.md#e-utilities

# clear the decks
rm(list = ls())

library("seqinr") # Loading seqinr package

# Accession Numbers of Sequence Data
ACCESSION <- "M28829" # https://www.ncbi.nlm.nih.gov/nuccore/M28829 IncQ plasmid RSF1010

## CDS nucleotide FASTA
ffn.seqs <- read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta_cds_na&retmode=text"), seqtype="DNA", strip.desc=TRUE)

# get sequence annotations
unlist(getAnnot(ffn.seqs))

#getwd()
#list.files()
sessionInfo()
Sys.time()

