#' # assignment
#' ## [ペアワイズ配列アラインメント](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#pairwise-sequence-alignment)
#' ## [Pairwise Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html)
#' - [Exercises](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#exercises)
#' - [Answers to the exercises on Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#sequence-alignment)

#+ echo = FALSE
# clear the decks
rm(list = ls())

#+ message = FALSE
# load the packages
library(seqinr) # read.fasta # c2s # getAnnot
library(Biostrings) # pairwiseAlignment # writePairwiseAlignments

#' Answer the following questions. For each question, please record your answer, and what you typed into R to get this answer.
#' You can submit your assignment as a PDF/HTML document, created from R script, R Markdown, Jupyter Notebook, and so on.
#' 
#' Q1. Download FASTA-format files of two protein sequences of interest from UniProt.
seq1 <- read.fasta(file = "http://www.uniprot.org/uniprot/Q9CD83.fasta")[[1]]; length(seq1); getAnnot(seq1)
seq2 <- read.fasta(file = "http://www.uniprot.org/uniprot/A0PQ23.fasta")[[1]]; length(seq2); getAnnot(seq2)
s1 <- toupper(c2s(seq1)) # convert the sequence to a string and to uppercase
s2 <- toupper(c2s(seq2)) # convert the sequence to a string and to uppercase

#' Q2. What is the alignment score for the optimal global alignment between the two proteins, when you use the BLOSUM50 scoring matrix?
#' (set gapOpening = -9.5 and gapExtension = -0.5)
data(BLOSUM50) # load the BLOSUM50 scoring matrix
myglobalAlign <- pairwiseAlignment(s1, s2, substitutionMatrix = "BLOSUM50", 
                                   gapOpening = -9.5, gapExtension = -0.5) # align the two sequences
myglobalAlign

#' Q3. Use the writePairwiseAlignments() function to view the optimal global alignment.

writePairwiseAlignments(myglobalAlign)

#' Q4. What global alignment score do you get for the two proteins, when you use the BLOSUM62 alignment matrix?

data(BLOSUM62) # load the BLOSUM62 scoring matrix
myglobalAlign2 <- pairwiseAlignment(s1, s2, substitutionMatrix = "BLOSUM62", 
                                    gapOpening = -9.5, gapExtension = -0.5) # align the two sequences
myglobalAlign2
writePairwiseAlignments(myglobalAlign2)

#' Q5. What is the alignment score for the optimal local alignment between the two proteins?
mylocalAlign <- pairwiseAlignment(s1, s2, substitutionMatrix = "BLOSUM50", 
                                  gapOpening = -9.5, gapExtension = -0.5, type="local")
mylocalAlign
writePairwiseAlignments(mylocalAlign)

# Print R version and packages
sessionInfo()
Sys.time()


