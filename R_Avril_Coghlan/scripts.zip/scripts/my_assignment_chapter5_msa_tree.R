#' # assignment
#' ## [多重配列アライメントと系統樹](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#multiple-alignment-and-phylogenetic-trees)
#' ## [Multiple Alignment and Phylogenetic trees](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html)
#' - [Exercises](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' - [Answers to the exercises on Multiple Alignment and Phylogenetic Trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)

#+ echo = FALSE
# clear the decks
rm(list = ls())

#+ message = FALSE
# libraries I need (no need to install...)
library(seqinr) # read.fasta # write.fasta # read.alignment # dist.alignment # getAnnot
suppressMessages(library(Biostrings)) # readAAStringSet # writeXStringSet
library(msa) # msa
library(ape) # nj # plot.phylo # root
library(microseq) # 

#' Answer the following questions. For each question, please record your answer, and what you typed into R to get this answer.
#' You can submit your assignment as a PDF/HTML document, created from R script, R Markdown, Jupyter Notebook, and so on.
#' 
#' Q1. Calculate the genetic distances between >3 protein sequences of interest. 
#' Which are the most closely related proteins, based on the genetic distances?

# create a function to retrieve several sequences from UniProt
retrieve_seqs_uniprot <- function(ACCESSION) read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
library("seqinr") # This function requires the SeqinR R package

# retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
seqnames <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5"); outgroups <- c("Q9YRR4") # NS1

# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(seqnames,  retrieve_seqs_uniprot)

# get the number of elements
length(seqs)

# get the length of sequences
getLength(seqs)

# get sequence annotations
unlist(getAnnot(seqs))

# write out the sequences to a FASTA file
write.fasta(sequences=seqs, names=seqnames, file.out="myseq.fasta")

# Read an XStringSet object from a file
myAAStringSet <- readAAStringSet(file = "myseq.fasta")

# Multiple Sequence Alignment using ClustalW
myMsaAAMultipleAlignment <- msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment
print(myMsaAAMultipleAlignment, show="complete")

# write an XStringSet object to a file
writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "mymsa.fasta")

# read the FASTA-format alignment into R
mymsa <- read.alignment(file = "mymsa.fasta", format = "fasta")

# calculate the genetic distances between the protein sequences
mydist <- dist.alignment(mymsa)
mydist

#' Q2. Build an unrooted phylogenetic tree of the proteins, using the neighbour-joining algorithm. 
#' Which are the most closely related proteins, based on the tree?

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- nj(mydist)
plot.phylo(mytree, type="unrooted")

#' Q3. Build an unrooted phylogenetic tree of the proteins, based on a trimmed alignment of the proteins. 
#' Does this differ from the tree based on the untrimmed alignment (in Q2)? Can you explain why?
# Trimming a multiple sequence alignment by discarding columns with too many gaps.
msa <- readFasta(in.file = "mymsa.fasta")
print(nchar(msa$Sequence))
msa.trimmed <- msaTrim(msa, gap.end = 0.4, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "mymsa.trimmed.fasta", width = 80)

# read the FASTA-format alignment into R
mymsa <- read.alignment(file = "mymsa.trimmed.fasta", format = "fasta")
unlist(mymsa$seq)

# calculate the genetic distances between the protein sequences
mydist <- dist.alignment(mymsa)
mydist

# construct a phylogenetic tree
mytree <- nj(mydist)
plot.phylo(mytree, type="unrooted", main="unrooted phylogenetic tree for protein sequences")

#' Q4. Build a rooted phylogenetic tree of the proteins, based on a trimmed alignment, using an outgroup. 
#' Which are the most closely related proteins, based on the tree? 
#' What extra information does this tree tell you, compared to the unrooted tree in Q2?
mytree <- root(phy=mytree, outgroup=outgroups)
plot.phylo(mytree, type="phylogram", main="rooted phylogenetic tree for protein sequences")

# Saving a phylogenetic tree as a Newick-format tree file
write.tree(phy = mytree, file = "mytree.newick")

# Print R version and packages
sessionInfo()
Sys.time()
