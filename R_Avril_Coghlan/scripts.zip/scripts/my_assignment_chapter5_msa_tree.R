#' # assignment
#' ## [多重配列アライメントと系統樹](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#multiple-alignment-and-phylogenetic-trees)
#' ## [Multiple Alignment and Phylogenetic trees](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html)
#' - [Exercises](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#exercises)
#' - [Answers to the exercises on Multiple Alignment and Phylogenetic Trees](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#multiple-alignment-and-phylogenetic-trees)

#+ echo = FALSE
# clear the decks
rm(list = ls())

#library(help="seqinr")
#+ message = FALSE
# libraries I need (no need to install...)
library(seqinr) # ls("package:seqinr")
library(Biostrings)
library(msa)
library(ape)
library(microseq)

#' Answer the following questions. For each question, please record your answer, and what you typed into R to get this answer.
#' You can submit your assignment as a PDF/HTML document, created from R script, R Markdown, Jupyter Notebook, and so on.
#' 
#' Q1. Calculate the genetic distances between >3 protein sequences of interest. 
#' Which are the most closely related proteins, based on the genetic distances?

# create a function to retrieve several sequences from UniProt
retrieve_seqs_uniprot <- function(ACCESSION) seqinr::read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
#library("seqinr") # This function requires the SeqinR R package

# retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
seqnames <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5"); outgroups <- c("Q9YRR4") # NS1
seqnames <- c("P02994","P32471","P29547","P36008","P32324","P32769"); outgroups <- c("P32324") # EF2_YEAST
seqnames <- c("P33166","P0A6N3","Q8U152","P80868","P0A6N0","P61877"); outgroups <- c("P33166","P0A6N3","Q8U152") # EF

# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(seqnames,  retrieve_seqs_uniprot)

# get the number of elements
length(seqs)

# get the length of sequences
seqinr::getLength(seqs)

# get sequence annotations
unlist(seqinr::getAnnot(seqs))

# write out the sequences to a FASTA file
seqinr::write.fasta(sequences=seqs, names=seqnames, file.out="myseq.fasta")

# Read an XStringSet object from a file
myAAStringSet <- Biostrings::readAAStringSet(file = "myseq.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
myMsaAAMultipleAlignment <- msa::msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment
print(myMsaAAMultipleAlignment, show="complete")

# write an XStringSet object to a file
Biostrings::writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "mymsa.fasta")

# read the FASTA-format alignment into R
mymsa <- seqinr::read.alignment(file = "mymsa.fasta", format = "fasta")

# calculate the genetic distances between the protein sequences
mydist <- seqinr::dist.alignment(x = mymsa)
mydist
as.matrix(mydist)

#' Q2. Build an unrooted phylogenetic tree of the proteins, using the neighbour-joining algorithm. 
#' Which are the most closely related proteins, based on the tree?

# construct a phylogenetic tree with the neighbor joining algorithm
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted")

#' Q3. Build an unrooted phylogenetic tree of the proteins, based on a trimmed alignment of the proteins. 
#' Does this differ from the tree based on the untrimmed alignment (in Q2)? Can you explain why?
# Trimming a multiple sequence alignment by discarding columns with too many gaps.
#library(microseq)
msa.untrimmed <- microseq::readFasta(in.file = "mymsa.fasta")
print(nchar(msa.untrimmed$Sequence))
msa.trimmed <- microseq::msaTrim(msa = msa.untrimmed, gap.end = 0, gap.mid = 0)
print(nchar(msa.trimmed$Sequence))
microseq::writeFasta(fdta = msa.trimmed, out.file = "mymsa.trimmed.fasta", width = 80)

# read the FASTA-format alignment into R
mymsa <- seqinr::read.alignment(file = "mymsa.trimmed.fasta", format = "fasta")
unlist(mymsa$seq)

# calculate the genetic distances between the protein sequences
mydist <- seqinr::dist.alignment(x = mymsa)
mydist

# construct a phylogenetic tree
mytree <- ape::nj(mydist)
ape::plot.phylo(mytree, type = "unrooted", main="unrooted tree")

#' Q4. Build a rooted phylogenetic tree of the proteins, based on a trimmed alignment, using an outgroup. 
#' Which are the most closely related proteins, based on the tree? 
#' What extra information does this tree tell you, compared to the unrooted tree in Q2?
mydist <- seqinr::dist.alignment(x = mymsa)
mytree <- ape::nj(mydist)
mytree <- ape::root(phy = mytree, outgroup = outgroups, resolve.root = TRUE)
#mytree <- phangorn::midpoint(mytree)
#mytree <- phytools::midpoint.root(mytree)
mytree <- ape::ladderize(mytree, right = FALSE)
ape::plot.phylo(mytree, type="phylogram", main="rooted tree")

# Saving a phylogenetic tree as a Newick-format tree file
ape::write.tree(phy = mytree, file = "mytree.newick")

# Print R version and packages
#sessionInfo()
Sys.time()

