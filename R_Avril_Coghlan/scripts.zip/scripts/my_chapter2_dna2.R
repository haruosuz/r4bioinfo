#' ---
#' title: "[Little Book of R for Bioinformatics](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

# clear the decks
rm(list = ls())

#' ## [DNA配列の統計 (2)](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-2)
#' ## [DNA Sequence Statistics (2)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html)
#' ### [A little more introduction to R](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#a-little-more-introduction-to-r)
#' **続・R言語入門**

# log10() function to calculate the log to the base 10 of a scalar variable x
x <- 100
log10(x)

# mean() function to calculate the average of the values in a vector variable myvector:
myvector <- c(1,3,5,7,9)
mean(myvector)

# get the value of the 3rd element in the vector myvector
myvector[3]

#' [Rで繰り返しを含む数列の生成（rep関数、seq関数）](http://tips-r.blogspot.jp/2014/05/repseq.html)

# create a sequence of numbers

# create the sequence of numbers from 1-10 in steps of 1
seq(from=1, to=10, by=1)
1:10

# create a sequence of numbers from 1-10 in steps of 2
seq(from=1, to=10, by=2)

#' [30. 繰り返し文](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/30.html)  
#' for による繰り返し

# for loop to carry out the same command several times

# print out the square of each number between 1 and 10
for (i in 1:10) { print (i*i) }

# give a for loop a vector of numbers containing the values 2, 9, 100, and 133
myvector <- c(2, 9, 100, 133)
for (i in myvector) { print (i*i) }

# print out the square of every second number between 1 and 10
for (i in seq(from=1, to=10, by=2)) { print (i*i) }

#' [48. とりあえず plot()](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/48.html)

# plot a scatterplot of the values in v1 against the values in v2
v1 <- 1:5
v2 <- 5:1
plot(x=v1, y=v2, xlab="x", ylab="y")

# type: "p" for points, "l" for lines, "b" for both,
plot(x=v1, y=v2, xlab="x", ylab="y", type="b")

#' [31. 関数の定義](http://cse.naro.affrc.go.jp/takezawa/r-tips/r/31.html)  

# create our own functions

# create a function to calculate the value of 20 plus the square of some input number
myfunction <- function(x) { return(20 + (x*x)) }

# use the function for different input numbers (eg. 10, 25)
myfunction(10)
myfunction(25)

# view the code that makes up a function by typing its name
myfunction

#' `＃`の後が[コメント](http://yusuke-memo.blogspot.jp/2009/10/r.html)行となる。

# writing the comment text after the “#” sign
x <- 100
log10(x) # Finds the log to the base 10 of variable x.

#' ### [Reading sequence data with SeqinR](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#reading-sequence-data-with-seqinr)
#' **Rパッケージseqinrで配列データを読み込み**
#' 
#' DEN-1デング熱ウイルスのゲノム配列を取得する:  

# reading the sequence for the DEN-1 Dengue virus genome (NCBI accession: NC_001477)
library("seqinr") # Load the SeqinR package.
ACCESSION <- "NC_001477"
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
seq1 <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)[[1]]

# obtain nucleotides 452-535 of DNA sequence stored in the vector `seq1`
seq1[452:535]

# GC content of DNA sequence stored in the vector `seq1`
GC(seq1)

#' ### [Local variation in GC content](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#local-variation-in-gc-content)
#' **GC含量の局所変動**
#' は、[遺伝子の水平伝播](https://ja.wikipedia.org/wiki/遺伝子の水平伝播) [horizontal gene transfer](https://en.wikipedia.org/wiki/Inferring_horizontal_gene_transfer) や変異バイアス [mutation bias](https://en.wikipedia.org/wiki/Mutation_bias) を示唆
#' 
#' ### [A sliding window analysis of GC content](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#a-sliding-window-analysis-of-gc-content)
#' **GC含量のスライディングウィンドウ解析**

GC(seq1[1:2000])      # 塩基配列の 1-2000 番目のGC含量
GC(seq1[2001:4000])   # 塩基配列の 2001-4000 番目のGC含量
GC(seq1[4001:6000])   # 塩基配列の 4001-6000 番目のGC含量
GC(seq1[6001:8000])   # 塩基配列の 6001-8000 番目のGC含量
GC(seq1[8001:10000])  # 塩基配列の 8001-10000 番目のGC含量
GC(seq1[10001:10735]) # 塩基配列の 10001-10735 番目のGC含量

#' 配列を固定長（ここでは 2000 bp）の断片に分け、各配列断片のGC含量を計算する。このような方法はスライディングウィンドウ（sliding window）と呼ばれ、配列断片のサイズはウィンドウサイズ（window size）、配列断片を移動させるサイズはステップサイズ（step size）と呼ばれる。
#' 
#' - [よくわかるバイオインフォマティクス入門](https://www.kspub.co.jp/book/detail/5138212.html) p.86 GC skew
#' 
#' `zoo`パッケージを用いて、異なるウィンドウサイズ（2000, 1000, 300 bp）でスライディングウィンドウ解析を実行し、プロットする。
#' 
#install.packages("zoo")
library(zoo)
windowsize <- 2000
#windowsize <- 3000
#windowsize <- 300
x <- seq(from = 1, to = length(seq1)-windowsize, by = windowsize)
y <- rollapply(data = seq1, width = windowsize, by = windowsize, FUN = GC)
par(family="mono")
plot(x, y, type="b", xlab="Position (bp)", ylab="GC content")

#' - [Mean of a sliding window in R - Cross Validated](http://stats.stackexchange.com/questions/3051/mean-of-a-sliding-window-in-r)
#' - [ベクトルの一定範囲に関数を適用しながら逐次計算していく（ローリング処理）](http://d.hatena.ne.jp/teramonagi/20100831/1283261344)
#' 
#' ### [Over-represented and under-represented DNA words](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#over-represented-and-under-represented-dna-words)
#' **連続塩基組成の偏り**
#' 
#' [Genomic signature](https://en.wikipedia.org/wiki/Genomic_signature)  
#' [*k*-mer](https://en.wikipedia.org/wiki/K-mer)  
#' [dinucleotide relative abundances](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC17754/figure/F1/) 2連続塩基組成
#' 
#' <img alt="https://en.wikipedia.org/wiki/K-mer" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/K-mer_diagram.svg/203px-K-mer_diagram.svg.png" width=20%>

# Count oligomers (monomer/dimer/trimer/etc)
count(seq = seq1, wordsize = 2)

# rho statistic is the ratio of the observed to expected frequency of oligonucleotides
rho(sequence = seq1, wordsize = 2)

#' [ρ](https://ja.wikipedia.org/wiki/Ρ)統計量はDNA文字列の[観測値/期待値]を計算する。
#' 2連続塩基の場合、ρ値は次の通り計算される:  
#' 
#' ρ(xy) = f<sub>xy</sub> / (f<sub>x</sub> * f<sub>y</sub>),
#' 
#' ここで、f<sub>xy</sub>, f<sub>x</sub>, f<sub>y</sub>は、DNA配列中の文字列"xy", "x", "y"の頻度である。
#' 
#' 例えば、2連続塩基"GC"のρ値の計算式は:  
#' 
#' ρ(GC) = f<sub>GC</sub> / (f<sub>G</sub> * f<sub>C</sub>),
#' 
#' ここで、f<sub>GC</sub>, f<sub>G</sub>, f<sub>C</sub>は、DNA配列中の文字列"GC", "G", "C"の頻度である。
#' 
#' テスト用の配列データを作成する:

# Create tests
testseq <- s2c("aatgc")
count(testseq, 1) # Get the number of occurrences of 1-nucleotide DNA words
1/(2+1+1+1) # Get fG
1/(2+1+1+1) # Get fC
count(testseq, 2) # Get the number of occurrences of 2-nucleotide DNA words
1/(0+0+0+1+1+0+0+0+0+1+0+0+0+0+1+0) # Get fGC
0.25/(0.2*0.2) # Get rho(GC)

#' 2連続塩基 "aa" "ac" "ag" "at" "ca" "cc" "cg" "ct" "ga" "gc" "gg" "gt" "ta" "tc" "tg" "tt" のρ値（観測値/期待値）を計算する:  

# the ratio of the observed to expected frequency of dinucleotides
( af1 <- count(testseq, wordsize = 1) ) # absolute frequencies of 1-mer
( rf1 <- af1 / sum(af1) )               # relative frequencies of 1-mer
( af2 <- count(testseq, wordsize = 2) ) # absolute frequencies of 2-mer
( rf2 <- af2 / sum(af2) )               # relative frequencies of 2-mer
( oe.2 <- rf2 / apply(expand.grid(rf1, rf1), 1, prod) ) # observed / expected

#' `rho`関数を使う:  

# The rho statistic can be computed on each of the 16 dinucleotides
rho(sequence = testseq, wordsize = 2)

#' ### [Summary](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#summary)

#?seq() # creating a sequence of numbers
#?print() # printing out the value of a variable
#?plot() # making a plot (eg. a scatterplot)
#?numeric() # making a numeric vector of a particular length
#?function(){} # making a function

#' ### [Links and Further Reading](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#links-and-further-reading)

#' ### [Exercises](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter2.html#exercises)
#' **演習**
#' [回答例](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#dna-sequence-statistics-2)
#' 

sessionInfo()

