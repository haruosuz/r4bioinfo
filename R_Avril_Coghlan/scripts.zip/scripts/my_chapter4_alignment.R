#' ---
#' title: "[Little Book of R for Bioinformatics](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

#' ## [ペアワイズ配列アラインメント](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#pairwise-sequence-alignment)
#' ## [Pairwise Sequence Alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html)
#' 
#' **[2つの配列間でのアラインメント](https://ja.wikipedia.org/wiki/シーケンスアラインメント#ペアワイズアラインメント)**
#' 
#' ![https://ja.wikipedia.org/wiki/シーケンスアラインメント](https://upload.wikimedia.org/wikipedia/commons/8/86/Zinc-finger-seq-alignment2.png)
#' 
#' [変異](https://ja.wikipedia.org/wiki/突然変異)
#' [Mutation](https://en.wikipedia.org/wiki/Mutation)
#' 
#' ### [UniProt](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#uniprot)
#' [Swiss-Prot](https://ja.wikipedia.org/wiki/Swiss-Prot) タンパク質データベース
#' 
#' ### [Viewing the UniProt webpage for a protein sequence](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#viewing-the-uniprot-webpage-for-a-protein-sequence)
#' [ハンセン病（Leprosy）](https://ja.wikipedia.org/wiki/ハンセン病)の原因細菌[*Mycobacterium leprae*（らい菌）](https://ja.wikipedia.org/wiki/らい菌)の[コリスミ酸リアーゼ](https://ja.wikipedia.org/wiki/コリスミ酸リアーゼ)（chorismate lyase）タンパク質配列を検索するには、UniProtウェブサイト (http://www.uniprot.org) にアクセスし、ウェブページ上部の検索ボックスにUniProt accession [ Q9CD83 ] を入力して、"Search"ボタンを押す:  
#' ![](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/_images/P4_image0.png)
#' 
#' ### [Retrieving a UniProt protein sequence via the UniProt website](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#retrieving-a-uniprot-protein-sequence-via-the-uniprot-website)
#' **UniProtのウェブサイトからタンパク質配列を取得**
#' 
#' ハンセン病（Leprosy）の原因細菌*Mycobacterium leprae*（らい菌）と[ブルーリ潰瘍（Buruli ulcer）](https://ja.wikipedia.org/wiki/ブルーリ潰瘍)の原因細菌[*Mycobacterium ulcerans*](http://www.nih.go.jp/niid/ja/diseases/ha/buruli-ulcer/1366-idsc/iasr-topic/1793-dj3863.html)のコリスミ酸リアーゼタンパク質配列（UniProt accession は[Q9CD83](http://www.uniprot.org/uniprot/Q9CD83)と[A0PQ23](http://www.uniprot.org/uniprot/A0PQ23)）をFASTA形式（ファイル名"Q9CD83.fasta"と"A0PQ23.fasta"）で保存する。
#' 
#' `read.fasta()`関数で、FASTAファイルをRに読み込む:
#' 
#library(seqinr)
#seqMleprae <- read.fasta(file = "Q9CD83.fasta")[[1]]
#seqMulcerans <- read.fasta(file = "A0PQ23.fasta")[[1]]
#seqMleprae # Display the contents of the vector "seqMleprae"

#' ### [Retrieving a UniProt protein sequence using SeqinR](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#retrieving-a-uniprot-protein-sequence-using-seqinr)
#' **SeqinRでUniProtのタンパク質配列を取得**
  
#' [How can I access resources on this web site programmatically?](http://www.uniprot.org/help/programmatic_access)

library(seqinr)
seqMleprae <- read.fasta(file = "http://www.uniprot.org/uniprot/Q9CD83.fasta")[[1]]
seqMulcerans <- read.fasta(file = "http://www.uniprot.org/uniprot/A0PQ23.fasta")[[1]]
seqMleprae # Display the contents of "seqMleprae"

#' ### [Comparing two sequences using a dotplot](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)
#' **ドットプロットで2つの配列を比較**
#' タンパク質のアミノ酸配列や核酸の塩基配列の[相同性](https://ja.wikipedia.org/wiki/相同) [homology](https://en.wikipedia.org/wiki/Homology_%28biology%29) （共通の祖先に由来すること）は、配列類似性に基づいて判断される。  
#' [ドットプロット](https://ja.wikipedia.org/wiki/ドットプロット_%28バイオインフォマティクス%29) [Dot plot](https://en.wikipedia.org/wiki/Dot_plot_%28bioinformatics%29) とは、2本の配列を比較するためのグラフである。両軸に全く同じ配列をとれば、右上がりの対角線が現れる。
#' 
#' テスト用の配列データを作成する:

# Create tests
library(seqinr)

testseq <- s2c("tgca")
testseq

par(mfrow=c(1,2))
dotPlot(testseq, testseq)
dotPlot(rep(testseq,2), rep(testseq,2))

#' *M.leprae*と*M.ulcerans*のコリスミ酸リアーゼのタンパク質配列のドットプロットを作成する:
dotPlot(seqMleprae, seqMulcerans)

#' ### [Pairwise global alignment of DNA sequences using the Needleman-Wunsch algorithm](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#pairwise-global-alignment-of-dna-sequences-using-the-needleman-wunsch-algorithm)
#' **2つのDNA配列間のグローバル・アラインメント**
#' 
#' [**グローバルアラインメントとローカルアラインメント**](https://ja.wikipedia.org/wiki/シーケンスアラインメント#グローバルアラインメントとローカルアラインメント)
#' [*global* alignment and *local* alignment](https://towardsdatascience.com/pairwise-sequence-alignment-using-biopython-d1a9d0ba861f)
#' 
#' ![](https://upload.wikimedia.org/wikipedia/commons/4/4b/Global-local-alignment.png)
#' 
#' 【例題】DNA配列("GAATTC"と"GATTA")間の最適なグローバルアラインメントを見つける。
#' 
#' 例えば、塩基の一致(match)に+2のスコア、不一致(mismatch)に-1のペナルティ、ギャップ(gap)に-2のペナルティを与える。  
#' 以下のアラインメントのスコアは？
#' 
#' ```
#' # give a score of +2 to a match and a penalty of -1 to a mismatch, and a penalty of -2 to a gap.
#' 
#' # the score for the following alignment is 2 + 2 + (-1) + 2 + (-2) + (-1) = 2:
#' GAATTC
#' GATT-A
#' 
#' # What is the score for the following alignment?
#' GAATTC
#' GA-TTA
#' ```
#' 
#' *scoring matrix (substitution matrix)*
#' [置換行列 | スコアマトリックスの作り方](https://bi.biopapyrus.jp/seq/score-matrix.html)
#' 
#' [Bioconductorパッケージ`Biostrings`のインストール](https://github.com/haruosuz/r4bioinfo/tree/master/R_Avril_Coghlan#how-to-install-a-bioconductor-r-package)
#' 
#' Biostringsパッケージの`nucleotideSubstitutionMatrix()`関数でスコアマトリックス(置換行列)を作る:  
#' 
# make a scoring matrix which assigns a score of +2 to a match and -1 to a mismatch:
suppressMessages(library(Biostrings))
sigma <- nucleotideSubstitutionMatrix(match = 2, mismatch = -1, baseOnly = TRUE)
sigma # Print out the matrix

#' - [**Gap penalty**](https://en.wikipedia.org/wiki/Gap_penalty)
#' - [ClustalW ヘルプ | DDBJ](https://www.ddbj.nig.ac.jp/clustalw-help.html)
#' 
#' ギャップの最初の位置には、
#' ギャップ開始時のペナルティ *gap opening penalty* と
#' ギャップ継続時のペナルティ *gap extension penalty* を与える。
#' 隣接するギャップは一回の挿入・欠失で生じたと考える。
#' 
#' Instead of assigning the same penalty (eg. -8) to every gap position, it is common instead to assign a gap opening penalty to the first position in a gap (eg. -8), and a smaller gap extension penalty to every subsequent position in the same gap.
#' The reason for doing this is that it is likely that adjacent gap positions were created by the same insertion or deletion event, rather than by several independent insertion or deletion events. 
#' 
#' `pairwiseAlignment()`関数で、DNA配列("GAATTC"と"GATTA")間の最適なグローバルアラインメントを見つける:  
  
# print out the optimal global alignment for the two sequences and its score:
s1 <- "GAATTC"
s2 <- "GATTA"
globalAligns1s2 <- pairwiseAlignment(s1, s2, substitutionMatrix = sigma, 
                                     gapOpening = -2, gapExtension = -8, scoreOnly = FALSE)
globalAligns1s2 # Print out the optimal alignment and its score

#' Note that we set “gapOpening” to be -2 and “gapExtension” to be -8, which means that the first position of a gap is assigned a score of (-8-2=)-10, and every subsequent position in a gap is given a score of -8. Here the alignment contains four matches, one mismatch, and one gap of length 1, so its score is (4\*2)+(1\*-1)+(1\*-10) = -3.
#' 
#' このアラインメントは、4個の一致(match)、1個の不一致(mismatch)、長さ1の1個のギャップ(gap)が含まれているので、スコアは (4\*2)+(1\*-1)+(1\*-10) = -3 となる。
#' 【注意】gapOpening = -2, gapExtension = -8 は、ギャップの最初の位置は (-2-8=)-10 のスコアが割り当てられ、ギャップの後続の位置は -8 のスコアが与えられることを意味する。
#' 
#' ### [Pairwise global alignment of protein sequences using the Needleman-Wunsch algorithm](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#pairwise-global-alignment-of-protein-sequences-using-the-needleman-wunsch-algorithm)
#' **2つのタンパク質配列間のグローバル・アラインメント**
#' 
#' アミノ酸置換行列 [BLOSUM (BLOcks SUbstitution Matrix)](https://en.wikipedia.org/wiki/BLOSUM)
#' 

# load the BLOSUM50 matrix
data(BLOSUM50)
BLOSUM50 # Print out the data

# get a list of the available scoring matrices that come with the Biostrings package:
data(package="Biostrings")

#' タンパク質配列("PAWHEAE"と"HEAGAWGHEE")間の最適なグローバルアラインメントを見つける:  
#' 
# find the optimal global alignment between two protein sequences using the BLOSUM50 matrix:
data(BLOSUM50)
s3 <- "PAWHEAE"
s4 <- "HEAGAWGHEE"
globalAligns3s4 <- pairwiseAlignment(s3, s4, substitutionMatrix = "BLOSUM50", 
                                     gapOpening = -2, gapExtension = -8, scoreOnly = FALSE)
globalAligns3s4 # Print out the optimal global alignment and its score

#' We set “gapOpening” to be -2 and “gapExtension” to be -8, which means that the first position of a gap is assigned a score of (-8-2=)-10, and every subsequent position in a gap is given a score of -8. This means that the gap will be given a score of -10-8-8 = -26.
#' 
#' ギャップ(`---`)は -10-8-8 = -26 のスコアが与えられる。
#' 
#' ### [Aligning UniProt sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#aligning-uniprot-sequences)
#' **UniProt配列のアラインメント**
#' 
library(seqinr)
seqMleprae <- read.fasta(file = "http://www.uniprot.org/uniprot/Q9CD83.fasta")[[1]]
seqMulcerans <- read.fasta(file = "http://www.uniprot.org/uniprot/A0PQ23.fasta")[[1]]

# 文字ベクトルを文字列に変換
# convert vectors of characters into strings
sMleprae <- c2s(seqMleprae) # Make a string that contains the sequence in "seqMleprae"
sMulcerans <- c2s(seqMulcerans) # Make a string that contains the sequence in "seqMulcerans"

# 大文字に変換
# convert strings to uppercase 
sMleprae <- toupper(sMleprae)
sMulcerans <- toupper(sMulcerans)
sMleprae # Print out the content of "sMleprae"

# align the two protein sequences
# library(Biostrings); data(BLOSUM50)
globalAlignMlepraeMulcerans <- pairwiseAlignment(sMleprae, sMulcerans, substitutionMatrix = BLOSUM50, gapOpening = -2, gapExtension = -8, scoreOnly = FALSE)

globalAlignMlepraeMulcerans # Print out the optimal global alignment and its score

#' ### [Viewing a long pairwise alignment](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#viewing-a-long-pairwise-alignment)
#' **2つの配列間のアラインメントの表示と出力**
#' 
# print out the alignment
writePairwiseAlignments(globalAlignMlepraeMulcerans)

# Write a PairwiseAlignments object to a file
writePairwiseAlignments(globalAlignMlepraeMulcerans, file="globalAlignMlepraeMulcerans.txt")

#getwd()
#list.files()

#' ### [Pairwise local alignment of protein sequences using the Smith-Waterman algorithm](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#pairwise-local-alignment-of-protein-sequences-using-the-smith-waterman-algorithm)
#' **2つのタンパク質配列間のローカル・アラインメント**

# find the best local alignment between the two protein sequences
localAlignMlepraeMulcerans <- pairwiseAlignment(sMleprae, sMulcerans, substitutionMatrix = BLOSUM50, gapOpening = -2, gapExtension = -8, scoreOnly = FALSE, type="local")

localAlignMlepraeMulcerans # Print out the optimal local alignment and its score

writePairwiseAlignments(localAlignMlepraeMulcerans)

#' We see that the optimal local alignment is quite similar to the optimal global alignment in this case, except that it excludes a short region of poorly aligned sequence at the start and at the ends of the two proteins.
#' 
#' ### [Calculating the statistical significance of a pairwise global alignment](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#calculating-the-statistical-significance-of-a-pairwise-global-alignment)
#' **ペアワイズグローバルアラインメントの統計的有意性の計算**
#' 
#' <img src="https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/_images/P4_image3.png" alt="" width=25%>

#' 
sessionInfo()

