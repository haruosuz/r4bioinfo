#' ---
#' title: "My Report"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

#' # [Compiling Reports from R Scripts](https://rmarkdown.rstudio.com/articles_report_from_r_script.html)
#' 
#' # Chunk options
#' 
#' - https://r4ds.had.co.nz/r-markdown.html#chunk-options
#' 
rm(list = ls())

# Load the packages into R:

#+ eval = FALSE
library(tidyverse)

#+ include = FALSE
library(seqinr)
library(Biostrings)
library(msa)
library(ape)

#+ warning = FALSE
#+ message = FALSE
library(zoo)

#+ echo = FALSE
#+ fig.show = "hide"
#+ results = "hide"
# To Get Some Protein Statistics
example(AAstat)

#' - https://r4ds.had.co.nz/r-markdown.html#text-formatting-with-markdown
#' 
#' # Text formatting 
#' 
#' - *italic* or _italic_
#' - **bold** or __bold__
#' - `code`
#' - superscript^2^ and subscript~2~
#' 
#' # Headings
#' 
#' # 1st Level Header
#' ## 2nd Level Header
#' ### 3rd Level Header
#' 
#' # Lists
#' 
#' * Bulleted list item 1
#' * Item 2
#'   * Item 2a
#'   * Item 2b
#' 1.  Numbered list item 1
#' 1.  Item 2. The numbers are incremented automatically in the output.
#' 
#' # Links and images
#' 
#' <https://r4ds.had.co.nz/> 
#' 
#' [R for Data Science](https://r4ds.had.co.nz/)
#' 
#' ![optional caption text](https://images-fe.ssl-images-amazon.com/images/I/91WTLn1DrBL._AC_UL160_.jpg)
#' 
#' ![https://www.fifthdimension.jp/documents/molphytextbook/](analysis/datapreparation_lecture_p25.jpg)
#' 
#' <img alt="datapreparation_lecture_p25.jpg" src="analysis/datapreparation_lecture_p25.jpg" width=30%>
#' 
#' <img alt="datapreparation_lecture_p28.jpg" src="analysis/datapreparation_lecture_p28.jpg" width=30%>
#' 
#' # Tables 
#' 
#' First Header  | Second Header
#' ------------- | -------------
#' Content Cell  | Content Cell
#' Content Cell  | Content Cell

#' - https://r4ds.had.co.nz/r-markdown.html#table

mtcars[1:5, ]

knitr::kable(
  mtcars[1:5, ], 
  caption = "A knitr kable."
)

#' # References
#' - https://github.com/haruosuz/DS4GD/tree/master/2020giga
#' - https://github.com/haruosuz/introBI/tree/master/2020
#' - [R for Data Science](https://r4ds.had.co.nz/)
#'   - [27 R Markdown](https://r4ds.had.co.nz/r-markdown.html#code-chunks)
#'     - [27.4 Code chunks](https://r4ds.had.co.nz/r-markdown.html#code-chunks)
#'       - [27.4.2 Chunk options](https://r4ds.had.co.nz/r-markdown.html#chunk-options)
#' - The International MetaSUB Consortium. (2020) Global Genetic Cartography of Urban Metagenomes and Anti-Microbial Resistance. doi: https://doi.org/10.1101/724526
#' - Tokuda M, Suzuki H, Yanagiya K, Yuki M, Inoue K, Ohkuma M, Kimbara K and Shintani M (2020) Determination of Plasmid pSN1216-29 Host Range and the Similarity in Oligonucleotide Composition Between Plasmid and Host Chromosomes. Front. Microbiol. 11:1187. doi: https://doi.org/10.3389/fmicb.2020.01187
#' - Merino, N., Zhang, S., Tomita, Suzuki H. Comparative genomics of Bacteria commonly identified in the built environment. BMC Genomics 20, 92 (2019). https://doi.org/10.1186/s12864-018-5389-z
#' 
#' # Collect Information About the Current R Session
sessionInfo()
Sys.time()
