#' ---
#' title: "My Report"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

#' # [Compiling Reports from R Scripts](https://rmarkdown.rstudio.com/articles_report_from_r_script.html)
#' 
#' # Chunk options
#' 
#' - https://r4ds.had.co.nz/r-markdown.html#chunk-options
#' 
rm(list = ls())

# Load the packages into R:

#+ eval = FALSE
library(tidyverse)

#+ include = FALSE
library(seqinr)
library(Biostrings)
library(msa)
library(ape)

#+ warning = FALSE
#+ message = FALSE
library(zoo)

#+ echo = FALSE
#+ fig.show = "hide"
#+ results = "hide"
# To Get Some Protein Statistics
example(AAstat)

#' - https://r4ds.had.co.nz/r-markdown.html#text-formatting-with-markdown
#' 
#' # Text formatting 
#' 
#' - *italic* or _italic_
#' - **bold** or __bold__
#' - `code`
#' - superscript^2^ and subscript~2~
#' 
#' # Headings
#' 
#' # 1st Level Header
#' ## 2nd Level Header
#' ### 3rd Level Header
#' 
#' # Lists
#' 
#' *   Bulleted list item 1
#' *   Item 2
#'   * Item 2a
#'   * Item 2b
#' 1.  Numbered list item 1
#' 1.  Item 2. The numbers are incremented automatically in the output.
#' 
#' # Links and images
#' 
#' <https://r4ds.had.co.nz/> 
#' 
#' [R for Data Science](https://r4ds.had.co.nz/)
#' 
#' ![optional caption text](https://images-fe.ssl-images-amazon.com/images/I/91WTLn1DrBL._AC_UL160_.jpg)
#' 
#' # Tables 
#' 
#' First Header  | Second Header
#' ------------- | -------------
#' Content Cell  | Content Cell
#' Content Cell  | Content Cell

#' - https://r4ds.had.co.nz/r-markdown.html#table

mtcars[1:5, ]

knitr::kable(
  mtcars[1:5, ], 
  caption = "A knitr kable."
)

#' # Collect Information About the Current R Session
sessionInfo()
Sys.time()
