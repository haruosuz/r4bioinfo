rm(list = ls())

#' # References
#' - https://en.wikipedia.org/wiki/Cluster_analysis
#' - 2017-12-18 https://r-posts.com/how-to-perform-hierarchical-clustering-using-r/
#' - https://uc-r.github.io/hc_clustering
#' Hierarchical Cluster Analysis · UC Business Analytics R Programming Guide
#' - https://online.stat.psu.edu/stat555/node/86/
#' 10.2 - Example: Agglomerative Hierarchical Clustering | STAT 555
#' - 
#' - 11/7/2017 https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html
#' Module 24: An Intro to Phylogenetic Tree Construction in R
#'   - [Distance-based methods](https://fuzzyatelin.github.io/bioanth-stats/module-24/module-24.html#distance-based_methods)
#'     - UPGMA
#'     - Neighbor-joining
#' - 
#' - https://github.com/haruosuz/DS4GD/blob/master/2017/hclust.md
#' 
#' # Clustering
#' 
#' # Cluster Analysis
x1 <- c(5,4,1,5,5)
x2 <- c(1,2,5,4,5)
mat <- cbind(x1,x2)
rownames(mat) <- letters[1:5]

par(mfrow=c(1,2))

# Distance Matrix Computation
d <- dist(mat, method="manhattan")

# Hierarchical Clustering
hc <- hclust(d, method="single")

# Cophenetic Distances for a Hierarchical Clustering
#d2 <- cophenetic(hc); cor(d, d2)

# Cluster Dendrogram
plot(hc, hang = -1)

# Draw Rectangles Around Hierarchical Clusters
#rect.hclust(hc, h=5) # cutting at height h
rect.hclust(hc, k=3) # k clusters are produced

plot(mat, type="n", main="data", xlim=c(0,5), ylim=c(0,5))
text(mat, labels=rownames(mat))
mat

# Cut a Tree into Groups of Data
#cutree(hc, h=5) # heights where the tree should be cut
#cutree(hc, k=3) # the desired number of groups
g23 <- cutree(hc, k=c(2,3))
write.csv(cbind(mat,g23), file="R.ds4gd_hclust.cutree.csv")

#' # Multidimensional Scaling
d <- dist(mat, method="euclidean")
loc <- cmdscale(d)
par(mfrow=c(1,2))
plot(loc[, 1], loc[, 2], type="n", main="cmdscale", xlab="MDS1", ylab="MDS2")
text(loc[, 1], loc[, 2], labels=rownames(mat))

plot(mat, type="n", main="data")
text(mat, labels=rownames(mat))

#' # Heat Map
#' - http://www.opiniomics.org/you-probably-dont-understand-heatmaps/
#' 
