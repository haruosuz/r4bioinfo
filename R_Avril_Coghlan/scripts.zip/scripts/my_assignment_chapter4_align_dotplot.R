#' # assignment
#' ## [ドットプロットで2つの配列を比較](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot)
#' ## [Comparing two sequences using a dotplot](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)

# clear the decks
rm(list = ls())

# load the packages
library(seqinr)

#' Answer the following questions. For each question, please record your answer, and what you typed to get this answer.
#' You can submit your assignment as a PDF/HTML document, created from R script, R Markdown, Jupyter Notebook, and so on.
#' 
#' Q1. Download FASTA-format files of two protein sequences from UniProt.
c1 <- read.fasta(file = "http://www.uniprot.org/uniprot/Q9CD83.fasta")[[1]]; length(c1); getAnnot(c1)
c2 <- read.fasta(file = "http://www.uniprot.org/uniprot/A0PQ23.fasta")[[1]]; length(c2); getAnnot(c2)

#' Q2. Create a dotplot for two sequences.

par(mfrow=c(1,2))
dotPlot(seq1 = c1, seq2 = c2)
dotPlot(seq1 = c1, seq2 = c2, wsize = 2, wstep = 2, nmatch = 2)

#' Q3. Create a self-similarity dot-plot; i.e. Comparing the sequence against itself.

par(mfrow=c(1,2))
dotPlot(c1, c1)
dotPlot(c2, c2)

# Print R version and packages
sessionInfo()
Sys.time()
