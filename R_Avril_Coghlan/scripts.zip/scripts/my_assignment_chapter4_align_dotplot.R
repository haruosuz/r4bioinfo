#' # assignment
#' ## [ドットプロットで2つの配列を比較](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot)
#' ## [Comparing two sequences using a dotplot](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)

# clear the decks
rm(list = ls())

# load the packages
library(seqinr)

#' Answer the following questions. 
#' For each question, please record your answer, and what you typed to get this answer.
#' 
#' ### Q1. 
#' Download FASTA-format files of two protein sequences from UniProt.

# Chorismate pyruvate-lyase OS=Mycobacterium
accession1 <- "Q9CD83" # PHBS_MYCLE
accession2 <- "A0PQ23" # A0PQ23_MYCUA
chars1 <- read.fasta(file = paste0("http://www.uniprot.org/uniprot/",accession1,".fasta"), seqtype = "AA")[[1]]
chars2 <- read.fasta(file = paste0("http://www.uniprot.org/uniprot/",accession2,".fasta"), seqtype = "AA")[[1]]

# get sequence length and annotation
length(chars1); getAnnot(chars1)
length(chars2); getAnnot(chars2)

#' ### Q2. 
#' Create a dotplot for two sequences.

par(mfrow=c(1,2))
dotPlot(seq1 = chars1, seq2 = chars2)
dotPlot(seq1 = chars1, seq2 = chars2, wsize = 2, wstep = 2, nmatch = 2)

#' ### Q3. 
#' Create a self-similarity dot-plot; i.e. Comparing the sequence against itself.

par(mfrow=c(1,2))
dotPlot(chars1, chars1)
dotPlot(chars2, chars2)

# Print R version and packages
sessionInfo()
Sys.time()
