#' # assignment
#' ## [ドットプロットで2つの配列を比較](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#comparing-two-sequences-using-a-dotplot)
#' ## [Comparing two sequences using a dotplot](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter4.html#comparing-two-sequences-using-a-dotplot)
#' 

rm(list = ls())
library(seqinr)

#' Answer the following questions. For each question, please record your answer, and what you typed to get this answer.
#' You can submit your assignment as a PDF/HTML document, created from R script, R Markdown, Jupyter Notebook, and so on.
#' 
#' Q1. Download FASTA-format files of two protein sequences from UniProt.
seq1 <- read.fasta(file = "http://www.uniprot.org/uniprot/Q9CD83.fasta")[[1]]; length(seq1); getAnnot(seq1)
seq2 <- read.fasta(file = "http://www.uniprot.org/uniprot/A0PQ23.fasta")[[1]]; length(seq2); getAnnot(seq2)

#' Q2. Create a dotplot for two sequences.

par(mfrow=c(1,2))
dotPlot(seq1, seq2)
dotPlot(seq1, seq2, wsize = 2, wstep = 2, nmatch = 2)

#' Q3. Create a self-similarity dot-plot; i.e. Comparing the sequence against itself.

par(mfrow=c(1,2))
dotPlot(seq1, seq1)
dotPlot(seq2, seq2)

# Print R version and packages
sessionInfo()
Sys.time()
