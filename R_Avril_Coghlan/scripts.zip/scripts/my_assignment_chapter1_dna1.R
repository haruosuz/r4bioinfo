#' # assignment
#' ## [DNA配列の統計 (1)](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#dna-sequence-statistics-1)
#' ## [DNA Sequence Statistics (1)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter1.html)
#' - [Exercises](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter1.html#exercises)
#' - [Answers to the exercises on DNA Sequence Statistics (1)](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter_answers.html#dna-sequence-statistics-1)

# clear the decks
rm(list = ls())

# load the packages
library(seqinr) # read.fasta # GC # comp # count

#' http://www.ncbi.nlm.nih.gov/genome/browse/
#' 
#' Download the DNA sequence of your genome of interest. 
#' Answer the following questions. 
#' For each question, please record your answer, and what you typed to get this answer.

# Retrieving a DNA sequence from NCBI
ACCESSION <- "NC_045512" # SARS-CoV-2
ACCESSION <- "NC_001477" # Dengue virus 1
ACCESSION <- "NC_002677" # Mycobacterium leprae strain TN
ACCESSION <- "NC_001318" # Borreliella burgdorferi B31 chromosome
filename <- paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text")
#filename <- paste0("http://togows.org/entry/nucleotide/",ACCESSION,".fasta")
seqs <- read.fasta(file=filename, seqtype="DNA", strip.desc=TRUE)
seq1 <- seqs[[1]]
getAnnot(seq1) # Get sequence annotations

#' ### Q1. 
#' What are the last 30 nucleotides of the genome sequence?

tail(seq1, 30)

#' [SARS-CoV-2 RNAs carry poly(A) tails](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7179501/)
#' 
#' ### Q2. 
#' What is the length in nucleotides of the genome sequence?

length(seq1)

#' ### Q3. 
#' How many of each of the four nucleotides A, C, T and G, 
#' and any other symbols, are there in the genome sequence?

table(seq1)

#' [Borreliella burgdorferi B31](https://www.ncbi.nlm.nih.gov/genome/738?genome_assembly_id=168382)
#' chromosome does contain non-A/C/G/T nucleotides.
#' 
#' DDBJ 
#' [Codes Used in Sequence Description](https://www.ddbj.nig.ac.jp/ddbj/code-e.html)
#' [配列の記載に用いる略号](https://www.ddbj.nig.ac.jp/ddbj/code.html)
#' 
#' ### Q4. 
#' What is the GC content of the genome sequence, when 
#' (i) all non-A/C/T/G nucleotides are included, 
#' (ii) non-A/C/T/G nucleotides are discarded?
#help("GC")
GC(seq1)
GC(seq1, exact=FALSE)
GC(seq1, exact=TRUE)

#' [The GC content of the Mycobacterium leprae TN genome sequence is 57.8%.](https://www.ncbi.nlm.nih.gov/genome/903?genome_assembly_id=169891)
#' 
#' ### Q5. 
#' How many of each of the four nucleotides A, C, T and G 
#' are there in the complement of the genome sequence?

#help.search("complement")
#help("comp")
table(comp(seq1))

#' - Mar 14, 2018 [Practice writing the complementary strand of DNA and mRNA during transcription - YouTube](https://www.youtube.com/watch?v=9qyi6xgOjEk)
#' <img alt="" src="https://i.ytimg.com/vi/9qyi6xgOjEk/maxresdefault.jpg" width=35%>
#' 
#' ### Q6. 
#' How many occurrences of the DNA words CC, CG and GC occur in the genome sequence?

count(seq=seq1, wordsize=2)

#' ### Q7. 
#' How many occurrences of the DNA words CC, CG and GC occur in the 
#' (i) first 1000 and (ii) last 1000 nucleotides of the genome sequence?
#' How can you check that the subsequence that you have looked at is 1000 nucleotides long?

count(seq=head(seq1, 1000), wordsize=2)
count(seq=tail(seq1, 1000), wordsize=2)

# Print R version and packages
sessionInfo()
Sys.time()
