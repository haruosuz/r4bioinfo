#' ---
#' title: "Little Book of R for Bioinformatics"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' ---

#' ## [多重配列アライメントと系統樹](https://github.com/haruosuz/r4bioinfo/blob/master/R_Avril_Coghlan/README.md#multiple-alignment-and-phylogenetic-trees)
#' ## [Multiple Alignment and Phylogenetic trees](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html)
#' **多重配列アラインメントと系統樹**
#' 
#' - [多重整列](https://ja.wikipedia.org/wiki/多重整列) [マルチプルアライメント](http://bio-info.biz/article/ase_msa.html) [Multiple sequence alignment](https://en.wikipedia.org/wiki/Multiple_sequence_alignment) 
#' - [系統樹](https://ja.wikipedia.org/wiki/系統樹) [Phylogenetic tree](https://en.wikipedia.org/wiki/Phylogenetic_tree) 
#' - [系統学](https://ja.wikipedia.org/wiki/系統学) [Phylogenetics](https://en.wikipedia.org/wiki/Phylogenetics)
#' - [分子系統学](https://ja.wikipedia.org/wiki/分子系統学) [Molecular phylogenetics](https://en.wikipedia.org/wiki/Molecular_phylogenetics)
#' - 2018-07-30 [How to read a phylogenetic tree](https://artic.network/how-to-read-a-tree.html) | Author: Andrew Rambaut
#' - Sep 4, 2017 https://www.youtube.com/watch?v=t0iAm-JQcrs Parsimony 6:25
#' 
#' ![https://bioinf.comav.upv.es/courses/biotech3/theory/phylogeny.html](https://bioinf.comav.upv.es/courses/biotech3/static/phylogeny/phylo_msa.png)
#' 
#' - [SeaView - Multiplatform GUI for molecular phylogeny](http://doua.prabi.fr/software/seaview)
#' 
#' ### [Retrieving a list of sequences from UniProt](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#retrieving-a-list-of-sequences-from-uniprot)
#' **UniProtから複数の配列を取得**
#' 
#' [狂犬病ウイルス](https://ja.wikipedia.org/wiki/狂犬病ウイルス) Rabies virus, Mokola virus, Lagos bat virus, West Caucasian bat virus の 
#' Phosphoprotein のタンパク質配列（UniProt accession: 
#' [P06747](http://www.uniprot.org/uniprot/P06747), 
#' [P0C569](http://www.uniprot.org/uniprot/P0C569), 
#' [O56773](http://www.uniprot.org/uniprot/O56773), 
#' [Q5VKP1](http://www.uniprot.org/uniprot/Q5VKP1)）を取得し、FASTA形式で保存する:  
#' 
#' to retrieve the protein sequences for UniProt accessions P06747, P0C569, O56773 and Q5VKP1 (the accessions for rabies virus phosphoprotein, Mokola virus phosphoprotein, Lagos bat virus phosphoprotein and Western Caucasian bat virus phosphoprotein, respectively):

# create a function to retrieve several sequences from UniProt
retrieve_seqs_uniprot <- function(ACCESSION) read.fasta(file=paste0("http://www.uniprot.org/uniprot/",ACCESSION,".fasta"), seqtype="AA", strip.desc=TRUE)[[1]]
library("seqinr") # This function requires the SeqinR R package

# retrieve several sequences from UniProt
seqnames <- c("P06747", "P0C569", "O56773", "Q5VKP1") # Make a vector containing the names of the sequences
seqs <- lapply(seqnames,  retrieve_seqs_uniprot) # Retrieve the sequences and store them in list variable "seqs"

length(seqs)      # Print out the number of sequences retrieved
seq1 <- seqs[[1]] # Get the 1st sequence
seq1[1:20]        # Print out the first 20 letters of the 1st sequence
seq2 <- seqs[[2]] # Get the 2nd sequence
seq2[1:20]        # Print out the first 20 letters of the 2nd sequence

write.fasta(sequences=seqs, names=seqnames, file.out="myseq.aa.fasta")

#' ### [Installing the CLUSTAL multiple alignment software](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#installing-the-clustal-multiple-alignment-software)
#' 
#' 多重整列プログラム [Clustal](https://ja.wikipedia.org/wiki/Clustal)
#' 
#' ### [Creating a multiple alignment of protein, DNA or mRNA sequences using CLUSTAL](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#creating-a-multiple-alignment-of-protein-dna-or-mrna-sequences-using-clustal)
#' **CLUSTALを用いたタンパク質/DNA/mRNA配列の多重アラインメントの作成**

#+ message = FALSE
suppressMessages(library(Biostrings))
# Read an XStringSet object from a file
myAAStringSet <- readAAStringSet(file = "myseq.aa.fasta")

# Multiple Sequence Alignment using ClustalW
library(msa)
#?msa::msa
myMsaAAMultipleAlignment <- msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment

# write an XStringSet object to a file
writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "mymsa.fasta")

#getwd()
#list.files()

#' ### [Viewing a long multiple alignment](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#viewing-a-long-multiple-alignment)
#' **多重アラインメントの表示**

print(myMsaAAMultipleAlignment, show="complete")

#' ### [Reading a multiple alignment file into R](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#reading-a-multiple-alignment-file-into-r)
#' **多重アラインメントのファイルをRに読み込む**

mymsa <- read.alignment(file = "mymsa.fasta", format = "fasta")
names(mymsa)
unlist(mymsa$seq)

#' ### [Discarding very poorly conserved regions from an alignment](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#discarding-very-poorly-conserved-regions-from-an-alignment)
#' **アラインメントから保存度の低い領域を破棄する**
#' 
#' Trimming a multiple sequence alignment by discarding columns with too many gaps.
#' 
#' 多重配列アラインメントからギャップの多い列を破棄する

#+ message = FALSE
# install.packages("microseq")
library(microseq)
msa <- readFasta(in.file = "mymsa.fasta")
print(nchar(msa$Sequence))
msa.trimmed <- msaTrim(msa, gap.end = 0.5, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "mymsa.trimmed.fasta", width = 80)
#mymsa <- read.alignment(file = "mymsa.trimmed.fasta", format = "fasta")

#' ### [Calculating genetic distances between protein sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-protein-sequences)
#' **タンパク質配列間の遺伝的距離を計算する**
#' 

mydist <- dist.alignment(mymsa) # Calculate the genetic distances
mydist                          # Print out the genetic distance matrix

#' 距離行列より、遺伝的距離は、"O56773"と"P0C569"との間で最小（0.4142670）、"Q5VKP1"と"O56773"との間で最大（0.5067117）。
#' 
#' ### [Building an unrooted phylogenetic tree for protein sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-an-unrooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の無根系統樹の構築**
#' 
#' 距離行列に基づいて、[近隣結合法 NJ (Neighbor-Joining)](https://ja.wikipedia.org/wiki/近隣結合法) により系統樹を構築する。
#' 系統樹では、"O56773"と"P0C569"が群を形成、"Q5VKP1"と"P06747"が群を形成した。

#+ message = FALSE
#install.packages("ape")
library(ape)

# construct a phylogenetic tree with the neighbor joining algorithm
# infer a tree
mytree <- nj(mydist)
# bootstrap the tree
myboot <- boot.phylo(phy=mytree, x=as.matrix.alignment(mymsa), FUN=function(xx) nj(dist.alignment(as.alignment(xx))), B=100)
mytree$node.label <- myboot # make the bootstrap values be the node labels
# plot the tree:
plot.phylo(mytree, type="unrooted", show.node.label=TRUE)
#nodelabels(myboot, cex=0.7) # plot the bootstrap values

# get sequence annotations
unlist(getAnnot(seqs))

#' ### [Building a rooted phylogenetic tree for protein sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-rooted-phylogenetic-tree-for-protein-sequences)
#' **タンパク質配列の有根系統樹の構築**
#' 
#' フラビウイルス属に属するジカウイルス (Zika virus) とデングウイルス (Dengue virus) 
#' の非構造タンパク質 (Nonstructural protein 1; NS1) の相同タンパク質配列を取得し、
#' 多重配列アラインメントに基づく有根系統樹を構築する。
#' [外群](https://ja.wikipedia.org/wiki/外群)としてジカウイルスを選択し、系統樹に根をつける。
#' 
# retrieve several sequences from UniProt
# Make a vector containing the names of the sequences
seqnames <- c("Q9YRR4", "Q9YP96", "B0LSS3", "Q6TFL5", "Q32ZE1"); outgroups <- c("Q32ZE1") # NS1
# Retrieve the sequences and store them in list variable "seqs"
seqs <- lapply(seqnames,  retrieve_seqs_uniprot)

# write out the sequences to a FASTA file
write.fasta(sequences=seqs, names=seqnames, file.out="myseq.aa.fasta")

# Read an XStringSet object from a file
myAAStringSet <- readAAStringSet(file = "myseq.aa.fasta")

# Multiple Sequence Alignment using ClustalW
myMsaAAMultipleAlignment <- msa(inputSeqs=myAAStringSet, method="ClustalW")
myMsaAAMultipleAlignment

# write an XStringSet object to a file
writeXStringSet(x = unmasked(myMsaAAMultipleAlignment), filepath = "mymsa.fasta")

# Trimming a multiple sequence alignment by discarding columns with too many gaps.
msa <- readFasta(in.file = "mymsa.fasta")
print(nchar(msa$Sequence))
msa.trimmed <- msaTrim(msa, gap.end = 0.5, gap.mid = 0.9)
print(nchar(msa.trimmed$Sequence))
writeFasta(fdta = msa.trimmed, out.file = "mymsa.trimmed.fasta", width = 80)

# read the FASTA-format alignment into R
mymsa <- read.alignment(file = "mymsa.trimmed.fasta", format = "fasta")
unlist(mymsa$seq)

# calculate the genetic distances between the protein sequences
mydist <- dist.alignment(mymsa)
mydist

# construct a phylogenetic tree with the neighbor joining algorithm
# infer a tree
mytree <- nj(mydist)
mytree <- root(phy=mytree, outgroup=outgroups)
# bootstrap the tree
myboot <- boot.phylo(phy=mytree, x=as.matrix.alignment(mymsa), FUN=function(xx) root(phy=nj(dist.alignment(as.alignment(xx))), outgroup=outgroups), B=100)
mytree$node.label <- myboot # make the bootstrap values be the node labels
# plot the tree:
plot.phylo(mytree, type="phylogram", show.node.label=TRUE)
#nodelabels(myboot, cex=0.7) # plot the bootstrap values

# get sequence annotations
unlist(getAnnot(seqs))

#' ### [Saving a phylogenetic tree as a Newick-format tree file](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#saving-a-phylogenetic-tree-as-a-newick-format-tree-file)
#' **系統樹をNewick形式ファイルとして保存する**

write.tree(phy = mytree, file = "mytree.newick")

#' ### [Calculating genetic distances between DNA/mRNA sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#calculating-genetic-distances-between-dna-mrna-sequences)
#' **DNA/mRNA配列間の遺伝的距離を計算する**
#' 
#' Duvenhage virus, Mokola virus, Lagos bat virus v006株, Lagos bat virus V267株 の Phosphoprotein の mRNA配列（NCBI accession: 
#' [AF049115](https://www.ncbi.nlm.nih.gov/nuccore/AF049115), 
#' [AF049118](https://www.ncbi.nlm.nih.gov/nuccore/AF049118), 
#' [AF049114](https://www.ncbi.nlm.nih.gov/nuccore/AF049114), 
#' [AF049119](https://www.ncbi.nlm.nih.gov/nuccore/AF049119)）を取得し、FASTA形式で保存する:  
#' 
# create a function to retrieve several nucleotide sequences from NCBI
retrieve_ncbi_fna <- function(ACCESSION) read.fasta(file = paste0("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=nuccore&id=",ACCESSION,"&rettype=fasta&retmode=text"), seqtype="DNA", strip.desc=TRUE)[[1]]
library("seqinr") # This function requires the SeqinR R package

# retrieve several nucleotide sequences from NCBI
seqnames <- c("AF049115", "AF049118", "AF049114", "AF049119") # Make a vector containing the names of the sequences
seqs <- lapply(seqnames, retrieve_ncbi_fna) # Retrieve the sequences and store them in list variable "seqs"

# write out the sequences to a FASTA-format file
write.fasta(seqs, seqnames, file="myseq.dna.fasta")

# Read an XStringSet object from a file
myDNAStringSet <- readDNAStringSet(file = "myseq.dna.fasta")

# Multiple Sequence Alignment using ClustalW
myMsaDNAMultipleAlignment <- msa(myDNAStringSet)
myMsaDNAMultipleAlignment
print(myMsaDNAMultipleAlignment, show="complete")

# convert msa for the seqinr package
seqinr_alignment <- msaConvert(myMsaDNAMultipleAlignment, type="seqinr::alignment")

# calculate a genetic distance for DNA/mRNA sequences
myDNAbin <- as.DNAbin(seqinr_alignment)   # Convert the alignment to "DNAbin" format
mydist <- dist.dna(myDNAbin, model="K80") # Calculate the genetic distance matrix
mydist                                    # Print out the genetic distance matrix

#' ### [Building a phylogenetic tree for DNA or mRNA sequences](http://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#building-a-phylogenetic-tree-for-dna-or-mrna-sequences)
#' **DNA/mRNA配列の系統樹の構築**

# construct a phylogenetic tree with the neighbor joining algorithm
# infer a tree
mytree <- nj(mydist)
# bootstrap the tree
myboot <- boot.phylo(phy=mytree, x=as.matrix.alignment(seqinr_alignment), FUN=function(xx) nj(dist.dna(as.DNAbin(xx), model="K80")), B=100)
mytree$node.label <- myboot # make the bootstrap values be the node labels
# plot the tree:
plot.phylo(mytree, type="unrooted", show.node.label=TRUE)
#nodelabels(myboot, cex=0.7) # plot the bootstrap values

# get sequence annotations
unlist(getAnnot(seqs))

#' ### Summary

#library(seqinr)
?read.alignment
?dist.alignment

#library(msa)
?msa

#library(ape)
?dist.dna
#example(nj)
?write.tree

#' ### [Links and Further Reading](https://a-little-book-of-r-for-bioinformatics.readthedocs.io/en/latest/src/chapter5.html#links-and-further-reading)
